create function "removeDuplicates"()
  returns void
language plpgsql
as $$
DECLARE
    lastmodified timestamp;
    nextid integer;
    rec_item   RECORD;
	var_newid integer;
    curs1 CURSOR FOR SELECT "id", "Price", "RawAddress", "TotalArea", "Storey", "modified_at" FROM public."newParsers2" order by id;
BEGIN
nextid = 0;

OPEN curs1;

LOOP
    FETCH  curs1 INTO  rec_item;
	EXIT WHEN NOT FOUND;
    
	select id, "modified_at" into var_newid, lastmodified from public."newParsers2" where id > rec_item.id
			and "RawAddress" = rec_item."RawAddress"
			and "Price" > (rec_item."Price" - 0.01)
			and "Price" < (rec_item."Price" + 0.01)
			and "Storey" = rec_item."Storey"
			and "TotalArea" > (rec_item."TotalArea" - 0.01)
			and "TotalArea" < (rec_item."TotalArea" + 0.01)
			LIMIT 1;
	if var_newid is not NULL THEN
	    /*raise notice 'lastmodified: %; modified: %; ID: %; var_newid: %', lastmodified, rec_item."modified_at", rec_item.id, var_newid;*/
		if lastmodified < rec_item."modified_at" then
	        delete from public."newParsers2" where id = var_newid;
		else
		    delete from public."newParsers2" where id = rec_item.id;
		end if;
	    /*EXIT;
        delete from public."newParsers2" where id > var_id and "RawAddress" = var_address and "Price" > (var_price - 0.01)
	       and "Price" < (var_price + 0.01) and "TotalArea" > (var_totalarea - 0.01)
	       and "Price" < (var_totalarea + 0.01)*/
	END if;
	nextid = nextid + 1;
	/*IF nextid > 6000000 THEN
	   EXIT;
	END IF;*/
	
END LOOP;
END;

$$;

