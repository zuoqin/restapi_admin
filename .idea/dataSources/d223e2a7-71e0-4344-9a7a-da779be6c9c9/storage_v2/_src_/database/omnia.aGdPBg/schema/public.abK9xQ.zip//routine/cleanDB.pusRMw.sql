create function "cleanDB"()
  returns void
language plpgsql
as $$
DECLARE
    lastmodified timestamp;
BEGIN
    update "newParsers2" set "BuildingType" = 'деревянный' where "BuildingType" = 'дерево' or "BuildingType" = 'Дерево'
	or "BuildingType" = 'Деревянный' or "BuildingType" = 'брус' or "BuildingType" = 'Старый фонд '
	or "BuildingType" = 'дом брусовой' or "BuildingType" = 'дом рублено-насыпной' or "BuildingType" = 'дом рубленый' or
	"BuildingType" = 'дом типа «сэндвич»';

	update "newParsers2" set "BuildingType" = 'панельный' where "BuildingType" = 'Панельный' or "BuildingType" = 'панель'
	or "BuildingType" = 'Панельный '  or "BuildingType" = 'Панель' or "BuildingType" = 'дом панельный' or "BuildingType" = '
Панель';
	
	update "newParsers2" set "BuildingType" = 'кирпичный' where "BuildingType" = 'Кирпичный' or "BuildingType" = 'Кирпич' or
	"BuildingType" = 'Кирпичный ' or "BuildingType" = 'кирпич' or "BuildingType" = 'дом кирпично-насыпной' or
	"BuildingType" = 'дом кирпичный' or "BuildingType" = '
Кирпич';
	
    update "newParsers2" set "BuildingType" = 'кирпично-монолитный' where "BuildingType" = 'Монолитно-кирпичный '
    or "BuildingType" = 'Кирпично-Монолитный' or "BuildingType" = 'кирпич - монолит' or "BuildingType" = 
	'дом кирпично-монолитный' ;
	
	update "newParsers2" set "BuildingType" = 'блочный' where "BuildingType" = 'бетонные блоки' or "BuildingType" = '
Блоки'
    or "BuildingType" = 'шлакоблоки' or "BuildingType" = 'Блоки' or "BuildingType" = 'Блочный ' or "BuildingType" = 'дом блочный'
	or "BuildingType" ='дом железобетонный' or "BuildingType" = 'дом пенобетонный' or "BuildingType" = 'дом шлакоблочный' or
	"BuildingType" = 'металлоконструкции' or "BuildingType" = 'Щитовой ';
	
	update "newParsers2" set "BuildingType" = 'монолитный' where "BuildingType" = 'Монолитный '
    or "BuildingType" = 'Монолит' or "BuildingType" = 'монолит' or "BuildingType" = 'элитный' or
	"BuildingType" = 'дом каркасно-монолитный' or "BuildingType" = 'дом монолитно-каркасный' or "BuildingType" = 'дом монолитно-кирпичный'
	or "BuildingType" = 'дом монолитный' or "BuildingType" = '
Монолит';
	
	update "newParsers2" set "BuildingType" = 'сталинский' where "BuildingType" = 'Сталинский ';
END;

$$;

