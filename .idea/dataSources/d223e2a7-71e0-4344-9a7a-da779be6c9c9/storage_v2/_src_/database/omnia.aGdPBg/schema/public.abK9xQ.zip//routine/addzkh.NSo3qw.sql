create function addzkh()
  returns void
language plpgsql
as $$
DECLARE
    var_buildyear integer;
	var_district text;
	var_region text;
	var_area text;
	var_lat numeric(9,6);
	var_lon numeric(9,6);
    nextid integer;
    rec_item   RECORD;
	var_newid integer;
	r numeric (9,6);
    cnt integer;
    curs1 CURSOR FOR SELECT "id", "Lat", "Lon", "District", "BuildingYear", "MicroDistrict", "RawAddress", "Region"
	FROM public."newParsers2" where "Lat" > 0 and "Lon" > 0 --and
	--"City" != 'Москва' and
	--("BuildingYear" is null or "BuildingYear" = 0 or "BuildingYear" = -1 
	--or "MicroDistrict" is null or "MicroDistrict" = ''
	--or "District" is null or "District" = ''
	--or "Region" is null or "Region" = ''
	--)
	order by id;
BEGIN
nextid = 0;
	CREATE TEMP TABLE IF NOT EXISTS nearby (id int, "lat" numeric(9,6), "lon" numeric (9,6),
	"built_year" int, "city_district" text , "city_area" text, "region" text);
	truncate table nearby;
OPEN curs1;

LOOP
    FETCH  curs1 INTO  rec_item;
	EXIT WHEN NOT FOUND;
	r =0.003;
	LOOP 
        insert into nearby (id, "lat", "lon", "built_year", "city_district", "city_area", "region")
        select 
	        id, "lat", "lon", "built_year", "city_district", "city_area", "formalname_region" from public."zkh" where
            "lat" > rec_item."Lat" - r and "lat" < rec_item."Lat" + r
            and "lon" >  rec_item."Lon" - 2 * r and "lon" < rec_item."Lon" + 2 * r;
	    select count(id) into cnt from nearby;
	    if cnt > 0 THEN
			EXIT;
		ELSE
		    raise notice 'Did not found nearby recordes for id: % with lat: % and lon: % and radius: %', rec_item.id, rec_item."Lat", rec_item."Lon", r;
			r = r * 10;
	    END IF;
	END LOOP;
	
	select "built_year", "city_district", "city_area", "lat", "lon", "region"
	into var_buildyear, var_district, var_area, var_lat, var_lon, var_region
	from nearby where id in	    
			(select id from nearby where
			("lat" - rec_item."Lat")*("lat" - rec_item."Lat") + 
			("lon" - rec_item."Lon")*("lon" - rec_item."Lon")
			 = (							
			select min (
		    ("lat" - rec_item."Lat")*("lat" - rec_item."Lat") + 
			("lon" - rec_item."Lon")*("lon" - rec_item."Lon")
	        ) from nearby) LIMIT 1)			
			LIMIT 1;
	if rec_item."BuildingYear" < 1800 THEN
	    /*raise notice 'Updating % with empty buildyear: % with year: %',
		    rec_item."RawAddress", rec_item.id, var_buildyear;*/
	    update public."newParsers2" set "BuildingYear" = var_buildyear where id = rec_item.id;
	end if;
	if var_district = '' THEN
	    select "city_district" into var_district from nearby where "city_district" != '';
	END IF;
	
	if var_region = '' THEN
	    select "region" into var_region from nearby where "region" != '';
	END IF;
	
	if var_area = '' THEN
	    select "city_area" into var_area from nearby where "city_area" != '';
	END IF;
	if rec_item."District" is null or rec_item."District" = '' THEN
	    /*raise notice 'Updating % with empty District: % with District: %',
		    rec_item."RawAddress", rec_item.id, var_district;*/
	    update public."newParsers2" set "District" = var_area where id = rec_item.id;
	end if;
	
	if rec_item."MicroDistrict" is null or rec_item."MicroDistrict" = '' THEN
	    /*raise notice 'Updating % with empty RegionDistrict: % with RegionDistrict: %',
		    rec_item."RawAddress", rec_item.id, var_area;*/
	    update public."newParsers2" set "MicroDistrict" = var_district where id = rec_item.id;
	end if;
	
	if rec_item."Region" is null or rec_item."Region" = '' THEN
	    /*raise notice 'Updating % with empty District: % with District: %',
		    rec_item."RawAddress", rec_item.id, var_district;*/
	    update public."newParsers2" set "Region" = var_region where id = rec_item.id;
	end if;

	raise notice 'Updating id: % with lat: % and lon: %', rec_item.id, rec_item."Lat", rec_item."Lon";
	nextid = nextid + 1;
	/*insert into nearby1 select * from nearby;*/
	truncate table nearby;
	/*IF nextid > 999999999999900 THEN
	   EXIT;
	END IF;*/
	
END LOOP;
DROP TABLE IF  EXISTS nearby;
END;

$$;

